DELIMITER $$
DROP PROCEDURE IF EXISTS getFacultyMeeting$$
CREATE PROCEDURE getFacultyMeeting(IN p_fac_id varchar(10))
BEGIN
select m.m_date, m.venue, m.startTime, m.endTime, m.meeting_info from meeting m, faculty_meeting f where f.faculty_id=p_fac_id and f.meeting_id=m.meeting_id;
END $$
DELIMITER ;