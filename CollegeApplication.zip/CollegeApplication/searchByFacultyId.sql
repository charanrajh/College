DELIMITER $$
DROP PROCEDURE IF EXISTS searchByFacultyId$$
CREATE PROCEDURE searchByFacultyId(IN p_fac_id varchar(10), OUT p_name varchar(20), OUT p_dept_name varchar(30), OUT p_course_name varchar(20), OUT p_email varchar(30), OUT p_phone bigint(10), OUT p_dob datetime, OUT p_qualf varchar(30), OUT p_exp integer)
BEGIN
select f.name, d.dept_name, c.course_name, f.email, f.phone, f.dob, f.qualification, f.experience into p_name, p_dept_name, p_course_name, p_email, p_phone, p_dob, p_qualf, p_exp from faculty f, department d, course c where f.faculty_id = p_fac_id and f.dept_id = d.dept_id and f.course_id = c.course_id;
END $$
DELIMITER ;