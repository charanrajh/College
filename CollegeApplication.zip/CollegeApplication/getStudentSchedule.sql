DELIMITER $$
DROP PROCEDURE IF EXISTS getStudentSchedule$$
CREATE PROCEDURE getStudentSchedule(IN p_stud_id varchar(10))
BEGIN
select s.classroom_id, b.subject_name, s.day_of_the_week, s.starttime, s.endtime, f.name from schedule s, faculty f, subjects b, student_schedule p where p.stud_id=p_stud_id and p.schedule_id=s.schedule_id and s.subject_id=b.subject_id;
END $$
DELIMITER ;