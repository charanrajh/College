DELIMITER $$
DROP PROCEDURE IF EXISTS getAllStudents$$
CREATE PROCEDURE getAllStudents()
BEGIN
select s.stud_id, s.name, d.dept_name, s.semester, c.course_name, s.email, s.phone, s.dob from student s, department d, course c where s.dept_id=d.dept_id and s.course_id=c.course_id;
END $$
DELIMITER ;