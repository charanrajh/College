DELIMITER $$
DROP PROCEDURE IF EXISTS searchByStudId $$
CREATE PROCEDURE searchByStudId(IN p_stud_id varchar(10), OUT p_name varchar(20), OUT p_dept_name varchar(30),
OUT p_semester integer(10), OUT p_course_name varchar(20), OUT p_email varchar(30), OUT p_phone bigint(10), OUT p_dob datetime)
BEGIN
select s.name, d.dept_name, s.semester, c.course_name, s.email, s.phone, s.dob into p_name, p_dept_name, p_semester, p_course_name, p_email, p_phone, p_dob
from student s, department d, course c where s.stud_id = p_stud_id and s.dept_id = d.dept_id and s.course_id = c.course_id;
END $$
DELIMITER ;