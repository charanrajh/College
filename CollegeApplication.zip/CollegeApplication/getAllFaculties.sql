DELIMITER $$
DROP PROCEDURE IF EXISTS getAllfaculties$$
CREATE PROCEDURE getAllfaculties()
BEGIN
select f.faculty
_id, f.name, d.dept_name, c.course_name, f.email, f.phone, f.dob, f.qualification, f.experience from faculty f, department d, course c where f.dept_id = d.dept_id and f.course_id = c.course_id;
END $$
DELIMITER ;