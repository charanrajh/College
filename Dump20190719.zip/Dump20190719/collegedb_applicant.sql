-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: collegedb
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applicant`
--

DROP TABLE IF EXISTS `applicant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `applicant` (
  `applicant_id` varchar(10) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `interested_course` varchar(10) NOT NULL,
  `interested_branch` varchar(30) NOT NULL,
  `x_marks` int(11) NOT NULL,
  `xii_marks` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` varchar(10) DEFAULT 'pending',
  PRIMARY KEY (`applicant_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicant`
--

LOCK TABLES `applicant` WRITE;
/*!40000 ALTER TABLE `applicant` DISABLE KEYS */;
INSERT INTO `applicant` VALUES ('15','shubam','verma','BE','Aeronautical Engineering',87,90,'subh@gmail.com',654321,'123','rejected'),('27775','qweqwe','kasnjadnd','BE','Information Technology',12,12,'jhgsf@ygsegwf',123425364,'qwerty','rejected'),('32020','Mani','Mini','BE','Information Technology',35,35,'maniamnai@gmail.com',12345678,'qwerty','pending'),('34273','Kutti','Mani','BE','Information Technology',35,35,'mani2@gmail.com',123456,'qwerty','pending'),('38379','aaa','zxxxxxxx','BE','Aeronautical Engineering',12,12,'sdfsf@fwvs',1234567,'qwerty','rejected'),('4','chiranjeevi','pepakayala','BTECH','Communication Systems',98,95,'pepakayala.chiranjeevi@gmail.com',8106204295,'qwerty','rejected'),('44789','Losliya','sjfg','BTECH','Communication Systems',12,34,'qwerdtf@kjhgfd',1232123,'qwerty','pending'),('47984','Kutti','Mani','BE','Information Technology',35,35,'mani@gmail.com',12121212,'qwerty','rejected'),('49386','maalo','peelo','BE','Aeronautical Engineering',44,66,'fger@dfdbe',11212,'aspa','pending'),('55085','bababab','msmamama','BE','Aeronautical Engineering',11,11,'sdhjgsd@scjdhcbvsb',1234987654,'qwerty','rejected'),('61042','mamama','ashgagdh','BTECH','Information Technology',12,12,'jsf@jsdgvj',99282652,'qwerty','rejected'),('61397','qwe','eee','ME','Aeronautical Engineering',12,45,'sfsf@drdh',123345,'123','rejected'),('71049','lolol','popopo','BTECH','Information Technology',11,11,'sd@erge',883552762,'qwerty','rejected'),('87771','asds','sdfdsf','BE','Information Technology',12,11,'wedge@svfsdve',772562,'qwerty','rejected'),('90003','aa','qq','BE','Aeronautical Engineering',12,12,'qwqedq@sdvsfv',1123456,'qwerty','rejected'),('90926','abc','def','BE','Information Technology',21,98,'qwe@sfge',12345686,'qwe','rejected'),('93277','ss','ll','BTECH','Communication Systems',12,34,'asa@gmail.com',10101901,'123','rejected'),('98050','Mani','Mini','BE','Information Technology',30,20,'manimani@gmail.com',10909,'qwerty','rejected');
/*!40000 ALTER TABLE `applicant` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-19 18:06:55
