package com.virtusa.collegeapp.model;

public class Feedback {

private String user_name;
private String comment;

public String getUser_name() {
    return user_name;
}
public void setUser_name(String user_name) {
    this.user_name = user_name;
}
public String getComment() {
    return comment;
}
public void setComment(String comment) {
    this.comment = comment;
}

}
